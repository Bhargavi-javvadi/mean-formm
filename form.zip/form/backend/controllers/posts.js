// controllers/posts.js
const Post = require('../models/post');  // Assuming you have a Post model

// Fetch all posts
exports.fetchAll = async (req, res) => {
  try {
    const posts = await Post.find();  // Fetch all posts from the database
    res.status(200).json(posts);      // Send the posts as JSON
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch posts', error: err });
  }
};

// Create a new post
exports.postPost = async (req, res) => {
  const { title, body, user } = req.body;
  const newPost = new Post({ title, body, user });

  try {
    const savedPost = await newPost.save();  // Save the new post to the database
    res.status(201).json(savedPost);         // Send the saved post as JSON
  } catch (err) {
    res.status(500).json({ message: 'Failed to create post', error: err });
  }
};

// Delete a post
exports.deletePost = async (req, res) => {
  const postId = req.params.id;

  try {
    const deletedPost = await Post.findByIdAndDelete(postId);  // Delete post by ID
    if (!deletedPost) {
      return res.status(404).json({ message: 'Post not found' });
    }
    res.status(200).json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete post', error: err });
  }
};
