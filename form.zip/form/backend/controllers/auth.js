const { validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../util/database');

// Signup Controller
exports.signup = async (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }

  const { name, email, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 12);

    // Save user to database
    const result = await db.execute(
      'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
      [name, email, hashedPassword]
    );

    res.status(201).json({
      message: 'User registered!',
      userId: result[0].insertId,
    });
  } catch (err) {
    next(err);
  }
};

// Login Controller
exports.login = async (req, res, next) => {
  const { email, password } = req.body;

  try {
    const [user] = await db.execute('SELECT * FROM users WHERE email = ?', [email]);

    if (user.length !== 1) {
      return res.status(401).json({ message: 'A user with this email could not be found.' });
    }

    const storedUser = user[0];

    const isEqual = await bcrypt.compare(password, storedUser.password);

    if (!isEqual) {
      return res.status(401).json({ message: 'Wrong password!' });
    }

    const token = jwt.sign(
      { email: storedUser.email, userId: storedUser.id },
      process.env.JWT_SECRET || 'secretfortoken', // Use environment variables
      { expiresIn: '1h' }
    );

    res.status(200).json({ token, userId: storedUser.id });
  } catch (err) {
    next(err);
  }
};
